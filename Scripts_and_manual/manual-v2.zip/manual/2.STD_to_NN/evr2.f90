program prvdist
use evrdata
implicit none

real*8, parameter :: pi = acos(-1.0d0), m1=15.994914d0,m2=m1,&
m3=m2, mu = m1*(m2+m3)/(m1+m2+m3)*1.66054d-24

real*8 :: e_tra, maxb, ft, nrot, nvib, b, ct, bmax, temp, scatang, ge, petra,&
dfang, peint, wt, avprob

integer :: itrj, prob, ii, jj,  ntot, ivib, jrot, nstrat, istr, jtot, ltot, &
jmax, vmax, vind, jind, ne, kk, dele, rne, rvmax, rjmax
real*8,parameter::fwhm=0.1d0, dx=0.1d0
real*8::center,g,eps
real*8, allocatable, dimension(:) :: bstrat, wstrat, nstot, vdist, jdist, erovib, edist, &
nr, rvdist, rjdist, rerovib, redist
real*8, allocatable, dimension(:,:) :: rotdist, vibdist, erovibdist, &
rrotdist, rvibdist, rerovibdist
character (len=12) :: products
eps=fwhm/(2.0d0*dsqrt(log(2.0d0)))

open(unit=11,file="inp",status="old")
read(11,*)ntot, nstrat, bmax!, temp

call readener
dele=pde-rde
vmax=pmaxvib
jmax=pmaxrot
rvmax=rmaxvib
rjmax=rmaxrot

!write(110,*) rmaxvib, rmaxrot, remax
ne=200!nint(pemax/dx)+1
rne=200!nint(remax/dx)+1
!write(*,*)vmax,jmax,ne
!write(*,*)rvmax,rjmax,rne

allocate(bstrat(nstrat), wstrat(nstrat), vdist(0:vmax), nstot(nstrat), jdist(0:jmax),&
rotdist(0:jmax,nstrat), vibdist(0:vmax,nstrat), erovib(ne), erovibdist(ne,nstrat), &
edist(ne-1), nr(nstrat))

allocate(rvdist(0:rvmax), rjdist(0:rjmax), rrotdist(0:rjmax,nstrat), &
rvibdist(0:rvmax,nstrat), rerovib(rne), rerovibdist(rne,nstrat), &
redist(rne-1))

rotdist=0.0d0
vibdist=0.0d0
erovibdist=0.0d0
rrotdist=0.0d0
rvibdist=0.0d0
rerovibdist=0.0d0

do ii = 1, nstrat
  bstrat(ii) = bmax/dfloat(nstrat)*dfloat(ii)
end do
wstrat(1)=bstrat(1)**2/bmax**2
if (nstrat>1) then
  do ii=2,nstrat
    wstrat(ii)=(bstrat(ii)**2-bstrat(ii-1)**2)/bmax**2
  end do
end if

erovib=0.0d0
do ii=2,ne
 erovib(ii)=erovib(ii-1)+dx
end do

rerovib=0.0d0
do ii=2,rne
 rerovib(ii)=rerovib(ii-1)+dx
end do

open(unit=10,file="out",status="old")
maxb=0.0d0
nstot=0.0d0
vdist=0.0d0
jdist=0.0d0
edist=0.0d0
erovibdist=0.0d0
nr=0.0d0
rvdist=0.0d0
rjdist=0.0d0
redist=0.0d0
rerovibdist=0.0d0

do kk = 1,ntot
  prob=0
!TrjNum    Product  v_i  j_i  IniRelE_tra  ImpctParam ProductEint       v_f
!j_f  ScatAng DflecAng   ProdEtra    ColTime TotalTime
  read(10,*)itrj,products, ivib, jrot, e_tra, b, peint, nvib, nrot, scatang, dfang, petra, ct, ft
!  print*,itrj,ii
  do jj=1,nstrat
    if (b .le. bstrat(jj)) then
      istr = jj
      exit
     end if
  end do

  if (trim(products) .eq. 'O2+O3O1' .or. trim(products) .eq. 'O3+O1O2' ) prob=1
  !if (trim(products) .eq. 'O1+O2O3') prob=1
  if (prob>0 .and. b>maxb) maxb=b
  if (prob>0 ) then

    vind=nint(nvib)
    if (vind<0 ) vind=0
    jind=nint(nrot)
    if (vind>300) then
      cycle
!100   do ii = 0, pmaxvib
!        if (provibener(ii,jind) < 0.0d0) exit
!        if ((provibener(ii,jind)+provibener(ii+1,jind))/2.0d0 <=0.0d0) then
!          if (peint<=(provibener(ii,jind))) vind = ii
!        else
!          if (peint<=(provibener(ii,jind)+provibener(ii+1,jind))/2.0d0) vind = ii
!        end if
!      end do
!      if (vind>300) then
!        jind=jind+1
!        go to 100
!      end if
!      if (vind<300) then
!      call finderovib(vind,jind,peint,1)
!      end if
    end if
    if (vind>pmaxvib .or. jind > pmaxrot ) cycle
    if (provibener(vind,jind)<-1.0d0 ) then
      call finderovib(vind,jind,peint,1)
    end if
    if (petra < 0.0d0 ) cycle

    petra=e_tra+rrovibener(ivib,jrot)-dele-provibener(vind,jind)
    rotdist(jind,istr) = rotdist(jind,istr)+1.0d0
    vibdist(vind,istr) = vibdist(vind,istr)+1.0d0
    nr(istr)=nr(istr)+1.0d0

    do jj=2,ne
      if(petra<erovib(jj)) then
        erovibdist(jj-1,istr) = erovibdist(jj-1,istr)+1.0d0
        exit
      end if
    end do

    petra=provibener(vind,jind)
    do jj=2,ne
      if(petra<rerovib(jj)) then
        rerovibdist(jj-1,istr) = rerovibdist(jj-1,istr)+1.0d0
        exit
      end if
    end do

  end if

!  rvibdist(ivib,istr) = rvibdist(ivib,istr)+1.0d0
!  rrotdist(jrot,istr) = rrotdist(jrot,istr)+1.0d0

!  do jj=2,rne
!    if(e_tra<rerovib(jj)) then
!      rerovibdist(jj-1,istr) = rerovibdist(jj-1,istr)+1.0d0
!      exit
!    end if
!  end do

  nstot(istr)=nstot(istr)+1.0d0
end do

do jj=0,vmax
do ii=1,nstrat
  vdist(jj)=vdist(jj)+wstrat(ii)*vibdist(jj,ii)/nstot(ii)
end do
end do

do jj=0,jmax
do ii=1,nstrat
  jdist(jj)=jdist(jj)+wstrat(ii)*rotdist(jj,ii)/nstot(ii)
end do
end do

do jj=1,ne-1
do ii=1,nstrat
  edist(jj)=edist(jj)+wstrat(ii)*erovibdist(jj,ii)/nstot(ii)
end do
end do

!do jj=0,rvmax
!do ii=1,nstrat
!  rvdist(jj)=rvdist(jj)+wstrat(ii)*rvibdist(jj,ii)/nstot(ii)
!end do
!end do

!do jj=0,rjmax
!do ii=1,nstrat
!  rjdist(jj)=rjdist(jj)+wstrat(ii)*rrotdist(jj,ii)/nstot(ii)
!end do
!end do

do jj=1,rne-1
do ii=1,nstrat
  redist(jj)=redist(jj)+wstrat(ii)*rerovibdist(jj,ii)/nstot(ii)
end do
end do

avprob=0.0d0
do ii=1,nstrat
  avprob=avprob+wstrat(ii)*nr(ii)/nstot(ii)
end do
write(*,*)avprob, sum(nr), sum(nstot), maxb
write(*,*)sum(vdist), sum(jdist), sum(edist), sum(erovibdist)
write(*,*)sum(rvdist), sum(rjdist), sum(redist), sum(rerovibdist)

do jj=0,vmax
  write(106,*)jj,vdist(jj)
!  write(104,*)vdist
end do

do jj=0,jmax
  write(107,*)jj,jdist(jj)
!  write(104,*)jdist
end do

do jj=1,ne-1
  write(108,*)(erovib(jj)+erovib(jj+1))/2.0d0,edist(jj)/dx
!  write(104,*)edist/dx
end do

!do jj=0,rvmax
!  write(204,*)jj,rvdist(jj)
!  write(105,*)rvdist
!end do

!do jj=0,rjmax
!  write(205,*)jj,rjdist(jj)
!  write(105,*)rjdist
!end do

do jj=1,rne-1
  write(109,*)(rerovib(jj)+rerovib(jj+1))/2.0d0,redist(jj)/dx
!  write(104,*) redist/dx
end do

end program
