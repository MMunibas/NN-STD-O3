module evrdata
implicit none
real*8, allocatable, dimension (:,:) :: rrovibener, provibener, dummyarray
!real*8, allocatable, dimension (:) :: pbheight, rbheight
integer :: rmaxvib, rmaxrot, pmaxvib, pmaxrot
real*8 :: rde, pde, pemax, remax

contains

subroutine readener
implicit none
integer :: nv, nj, np
integer :: iv, ij, ii
real*8 :: wt 

nv=100
nj=400
open(unit=101,file="O2.dat",status="old") !product
open(unit=102,file="O2b.dat",status="old") !reactant
!open(unit=103,file="../N2_bheight",status="old") !reactant
!open(unit=104,file="../NO_bheight",status="old") !reactant

allocate (dummyarray(0:nv,0:nj))
dummyarray=-10.0d0
 
read(101,*)np,pde
pmaxvib=0
pmaxrot=0
pemax=0.0d0
do ii = 1, np
  read(101,*)iv,ij,wt,dummyarray(iv,ij)
  if (iv>pmaxvib)pmaxvib=iv
  if (ij>pmaxrot)pmaxrot=ij
  if (dummyarray(iv,ij)>pemax)pemax=dummyarray(iv,ij)
end do

allocate (provibener(0:pmaxvib,0:pmaxrot))!, pbheight(0:pmaxrot))

provibener(0:pmaxvib,0:pmaxrot)=dummyarray(0:pmaxvib,0:pmaxrot)
!pbheight=0.0d0
!do ii = 0, pmaxrot
!  read(103,*)ij,pbheight(ii)
!end do

deallocate (dummyarray)

allocate (dummyarray(0:nv,0:nj))
dummyarray=-10.0d0

read(102,*)np,rde
rmaxvib=0
rmaxrot=0
remax=0.0d0
do ii = 1, np
  read(102,*)iv,ij,wt,dummyarray(iv,ij)
  if (iv>rmaxvib)rmaxvib=iv
  if (ij>rmaxrot)rmaxrot=ij
  if (dummyarray(iv,ij)>remax)remax=dummyarray(iv,ij)
end do

allocate (rrovibener(0:rmaxvib,0:rmaxrot))!,rbheight(0:rmaxrot))

rrovibener(0:rmaxvib,0:rmaxrot)=dummyarray(0:rmaxvib,0:rmaxrot)
!rbheight=0.0d0
!do ii = 0, rmaxrot
!  read(104,*)ij,rbheight(ii)
!end do

deallocate (dummyarray)

end subroutine

subroutine finderovib(nv,nj,evib,cflag)
implicit none
integer, intent(in) :: cflag
integer, intent(inout) :: nv, nj
real*8, intent(inout) :: evib
integer :: iv, ij, ii, jj, np
real*8 :: devib
real*8, allocatable, dimension(:,:) :: dummyb, b

allocate(dummyb(120,3))
dummyb=-10.0d0
if (cflag<1) then
np=1
do iv=nv-5,nv+5
  do ij=nj-5,nj+5
    if (ij>rmaxrot .or. iv>rmaxvib )cycle
    if (ij<0 .or. iv<0 )cycle
    if (rrovibener(iv,ij)<-1.0d0) cycle
    dummyb(np,1)=dfloat(iv)
    dummyb(np,2)=dfloat(ij)
    dummyb(np,3)=rrovibener(iv,ij)
    np = np+1
  end do
end do
if (dummyb(np,3) <-1.0d0) np=np-1
else
np=1
do iv=nv-5,nv+5
  do ij=nj-5,nj+5
    if (ij>pmaxrot .or. iv>pmaxvib )cycle
    if (ij<0 .or. iv<0 )cycle
    if (provibener(iv,ij)<-1.0d0) cycle
    dummyb(np,1)=dfloat(iv)
    dummyb(np,2)=dfloat(ij)
    dummyb(np,3)=provibener(iv,ij)
    np = np+1
  end do
end do
if (dummyb(np,3) <-1.0d0) np=np-1
end if
allocate(b(np,3))
b(1:np,:)=dummyb(1:np,:)
!print*,np
deallocate(dummyb)

devib=1000.0d0
!print*,evib
!print*,b(:,3)
do ii = 1, np
   if(b(ii,3)>evib)cycle
   if(abs(evib-b(ii,3))<devib) then
     devib=abs(evib-b(ii,3))
     jj=ii
   end if
end do
!print*,jj

nv=b(jj,1)
nj=b(jj,2)
evib=b(jj,3)
deallocate(b)

return
end subroutine

end module

!program eval
!use evrdata
!implicit none
!integer :: iv, ij
!real*8 :: ener
!
!call readener
!
!print*, "rmaxvib, rmaxrot",rmaxvib, rmaxrot
!print*, "pmaxvib, pmaxrot",pmaxvib, pmaxrot
!print*,"v,j"
!read(*,*)iv, ij
!print*,"r",rrovibener(iv,ij),"p",provibener(iv,ij)
!
!read(*,*)iv, ij, ener
!call finderovib(iv,ij,ener,0)
!print*,iv,ij,ener
!
!read(*,*)iv, ij, ener
!call finderovib(iv,ij,ener,1)
!print*,iv,ij,ener
!
!end program
