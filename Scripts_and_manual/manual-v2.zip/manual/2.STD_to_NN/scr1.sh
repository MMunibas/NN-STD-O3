

productfile=outputpevj.dat
touch $productfile evjinput
rm $productfile evjinput
touch $productfile evjinput
 
for ivib in 0 2 4 6 8 10 12 15 18 21 24 27 30 34 38 42

do

for jrot in 1 5 15 29 43 57 71 95 109 123 137 151 165 179 193 207 221 235

do

for ecol in 0.5 1.0 1.5 2.0 2.5 3.0 3.5 4.0 4.5 5.0 6.0 7.0 8.0

do

if grep -q "^$ivib $jrot$" permit_vj.txt; then
echo "Processing ivib=$ivib, jrot=$jrot"

#v4-j105-E2.0-1
# ivib=0
# jrot=15
# ecol=7.5

fdir=v$ivib-j$jrot-E$ecol-1


#if [ -d $fdir ]
#then
#echo $fdir exists
#else
#echo $fdir does not exist
#continue
#fi

lnum=$(wc -l < $fdir/out)
#if [ $lnum -lt 8000 ]
#then
#echo $fdir calcualtion did not finish, lines = $lnum
#continue
#fi

touch out out2
rm out out2
touch out out2
for ii in {1..20}
do

dir=v$ivib-j$jrot-E$ecol-$ii

cp $dir/out out
sed -i '1d' out
sed -i '$a\' out
sed -i 's/\*\*\*\*\*\*\*\*\*\*\*/10.0/g' out
sed -i '/NaN/d' out
cat out >>out2
done
mv out2 out

#lnum=$(wc -l < $dir/out)
lnum=$(wc -l < out)
vno=$(grep "ivib=" $dir/input| head -n 1 | cut -d ' ' -f1 | cut -d '=' -f2 )
jno=$(grep "jrot=" $dir/input| head -n 1 | cut -d ' ' -f1 | cut -d '=' -f2 )
te=$(grep "e_tra=" $dir/input| head -n 1 | cut -d ' ' -f1 | cut -d '=' -f2 )
r12max=$(grep "r12max=" $dir/input| cut -d ' ' -f1 | cut -d '=' -f2 )
ro=$(grep "ro=" $dir/input| cut -d ' ' -f1 | cut -d '=' -f2 )
nstrat=$(grep "nstrat=" $dir/input| head -n 1 | cut -d ' ' -f1 | cut -d '=' -f2 )
bmax=$(grep "bmax=" $dir/input| cut -d ' ' -f1 | cut -d '=' -f2 )
nstate=$(grep  "Number of states included in this run" $dir/diatomic.para | cut -c45-52 )
echo  "v =" $vno $ivib "j =" $jno $jrot "E =" $te $ecol "bmax =" $bmax "nstrat =" $nstrat "lines = " $lnum "ns =" $nstrat

echo $lnum $nstrat $bmax >inp
./evrdists.x
#cat fort.104 >>$productfile
#rm fort.104 

echo $vno $jno $te $ivib $jrot $ecol >>evjinput

else

continue

fi

done

done

done