#!/bin/bash

cd /cluster/data/wjchun/o3sts 

ii=10
for ivib in 0 2 4 6 8 10 12 15 18 21 24 27 30 34 38 42
#for ivib in 42

do

#for jrot in 0 15 30 45 60 75 90 105 120 135 150 165 180 195 210 225 240
for jrot in 1 5 15 29 43 57 71 95 109 123 137 151 165 179 193 207 221 235

do

for ecol in 0.5 1.0 1.5 2.0 2.5 3.0 3.5 4.0 4.5 5.0 6.0 7.0 8.0

do

for jj in {1..20}

do

dir=v$ivib-j$jrot-E$ecol-$jj

if [ -d $dir ]
then
echo $dir exists
continue
else
echo $dir does not exist
mkdir $dir
fi


bmax=18.0

cd $dir
cp ../scr3.sh jobD-$ii.sh

sed -i s/XXXX/$ivib/g jobD-$ii.sh
sed -i s/YYYY/$jrot/g jobD-$ii.sh
sed -i s/ZZZZ/$ecol/g jobD-$ii.sh
sed -i s/AAAA/$jj/g jobD-$ii.sh

ro=20.0
r12max=24.0
seed=$(($ii*311+131))

cp ../tmp-input1 input
sed -i s/%seed%/$seed/g input
sed -i s/%ecol%/$ecol/g input
sed -i s/%ivib%/$ivib/g input
sed -i s/%jrot%/$jrot/g input
sed -i s/%bmax%/$bmax/g input
sed -i s/%r12max%/$r12max/g input
sed -i s/%ro%/$ro/g input

kk=$(squeue | grep wjchun | wc -l)
while [ $kk -gt 500 ]
do
sleep 60
kk=$(squeue | grep wjchun | wc -l)
done

sbatch jobD-$ii.sh
echo $dir submitted

cd ..

ii=$(($ii+1))
done

done

done

done
