#!/bin/bash
# give the job a name:
#SBATCH --job-name=vXXXX-jYYYY-EZZZZ-AAAA
# now define the number of physical nodes:
#SBATCH --nodes=1
# for openmpi, each core is a separate "task", so for 8 cores:
#SBATCH --ntasks=1
#SBATCH --partition=long

hostname

exct=qct.x

#cd /cluster/data/wjchun/o3sts/

cdir=$(pwd)
mkdir -p /scratch/$USER
sdir=/scratch/$USER/slurm-job.$SLURM_JOBID
if [ -d $sdir ]
then
rm -r $sdir
fi

mkdir -p $sdir
export TMPDIR=$sdir


#ivib=XXXX
#jrot=YYYY
#ecol=ZZZZ
#bmax=BBBB
#ro=18.0
#r12max=24.0
#
#seed=$SLURM_JOBID #$(($ii*311+131))
#
#cp ../tmp-input1 input
#sed -i s/%seed%/$seed/g input
#sed -i s/%ecol%/$ecol/g input
#sed -i s/%ivib%/$ivib/g input
#sed -i s/%jrot%/$jrot/g input
#sed -i s/%bmax%/$bmax/g input
#sed -i s/%r12max%/$r12max/g input
#sed -i s/%ro%/$ro/g input

$cdir/../$exct >out 


#rm -rf $sdir

#flag=1
#while [ $flag -gt 0 ]
#do
#
#sleep 2
#flag=$(ps -u wjchun | grep $exct | wc -l)
#
#done
