#!/bin/bash

while read v0 j0
do
	vi=$v0
	ji=$j0
	cp input_template input
	sed -i "s/AAAA/"$vi"/" input
	sed -i "s/BBBB/"$ji"/" input
	../qct.x > out2
	tail -n +2 diatomic.para >> states.out
done<o2vj.dat
