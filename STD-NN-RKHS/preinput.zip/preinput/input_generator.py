import numpy as np
import matplotlib.pyplot as plt
import matplotlib.backends.backend_pdf
from scipy.optimize import curve_fit
import random

path = '../../amplitude/'

eV_to_joule = 1.602176565*(10**(-19))
hbar = 1.054571817*(10**(-34))
N_avo = 6.02214086*(10**(23))
m_O2 = 2*15.994914
m_O = 15.994914
mu_rel = (m_O2*m_O)/(m_O2+m_O)
features = np.genfromtxt('O2_states.dat', skip_header=1)

v = features[:, 0]
j = features[:, 1]
Evj = features[:, 2]
turn_l = features[:, 4]
turn_r = features[:, 3]
period = features[:, 5]

data = np.genfromtxt('evjinput.dat', delimiter=' ')


with open("input_new.txt", "w") as txt_file_main:
    for i in range(len(data)):
        print(i)
        for k in range(len(Evj)):
            if v[k] == int(data[i, 0]) and j[k] == int(data[i, 1]):
                Etrans_curr = data[i, 2]
                vel_curr = np.sqrt(2*Etrans_curr/mu_rel)
                v_curr = v[k]
                j_curr = j[k]
                angular_mom_curr = np.sqrt(j_curr*(j_curr+1))
                Evj_curr = Evj[k]
                turn_l_curr = turn_l[k]
                turn_r_curr = turn_r[k]
                period_curr = period[k]
            if v[k] == int(data[i, 0]) and j[k] == 0:
                Ev_curr = Evj[k]
            if v[k] == 0 and j[k] == int(data[i, 1]):
                Ej_curr = Evj[k]

        txt_file_main.write(str(Etrans_curr) + ',' + str(v_curr) + ',' + str(j_curr) + ',' + str(vel_curr) + ',' + str(Evj_curr) + ',' + str(Ev_curr) +
                            ',' + str(Ej_curr) + ',' + str(angular_mom_curr) + ',' + str(turn_l_curr) + ',' + str(turn_r_curr) + ',' + str(period_curr) + '\n')
