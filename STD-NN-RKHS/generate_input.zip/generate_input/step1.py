import numpy as np
import matplotlib.pyplot as plt
import matplotlib.backends.backend_pdf
from scipy.optimize import curve_fit
import random

path = '../../amplitude/'
plotting = False
external_plotting = False

Egridout = []
i = 0.0
while (i+0.1) < 2.0:
    Egridout.append(i)
    i = i + 0.1
while (i+0.2) < 5.0:
    Egridout.append(i)
    i = i + 0.2
while (i+0.2) < 12.0:
    Egridout.append(i)
    i = i + 0.2
while (i+0.3) < 16.0:
    Egridout.append(i)
    i = i + 0.3
Egridout.append(16.0)
Egridout = np.array(Egridout)

vgridout = []
i = 0
while (i + 1) < 42:
    vgridout.append(i)
    i = i + 1
vgridout.append(42)
vgridout = np.array(vgridout)

jgridout = []
i = 1
while (i + 2) < 241:
    jgridout.append(i)
    i = i + 2
jgridout.append(241)
jgridout = np.array(jgridout)


num_features = 11
num_outputs = len(Egridout) + len(vgridout) + len(jgridout)
print('Number of features: ' + str(num_features))
print('Number of outputs: ' + str(num_outputs))

# filenames = ['pevj', 'pv', 'pj']
# pdf = matplotlib.backends.backend_pdf.PdfPages("output.pdf")
# pdfE = matplotlib.backends.backend_pdf.PdfPages("output_E.pdf")
# pdfv = matplotlib.backends.backend_pdf.PdfPages("output_v.pdf")
# pdfj = matplotlib.backends.backend_pdf.PdfPages("output_j.pdf")
# # pdfall = matplotlib.backends.backend_pdf.PdfPages("output_all.pdf")
# features = np.genfromtxt('../preinput/input_new.txt', delimiter=',')
# normal_data = np.genfromtxt('indices_normal_prob.txt', delimiter=',').astype(int)
# low_prob_data = np.genfromtxt('indices_low_prob_not_excluded.txt', delimiter=',').astype(int)
# excluded_data = np.genfromtxt('indices_to_exclude.txt', delimiter=',').astype(int)


# seed = 33
# random.seed(seed)
# indices = list(total_data)
# test_indices = []
# with open("test_indices.txt", "w") as txt_file:
#     for i in range(240):
#         index = random.choice(indices)
#         indices.remove(index)
#         test_indices.append(index)
#         txt_file.write(str(index) + '\n')


with open("indices_normal_prob.txt", "w") as txt_file:
    for i in range(2418):
        E, p = np.loadtxt(path + 'pv' + str(i+1) + '.dat', unpack=True)
        if np.sum(p) >= 0.01:
            txt_file.write(str(i) + '\n')

with open("indices_low_prob.txt", "w") as txt_file:
    for i in range(2418):
        E, p = np.loadtxt(path + 'pv' + str(i+1) + '.dat', unpack=True)
        if (np.sum(p) < 0.01) and (np.sum(p) >= 0.005):
            txt_file.write(str(i) + '\n')

with open("indices_to_exclude.txt", "w") as txt_file:
    for i in range(2418):
        E, p = np.loadtxt(path + 'pv' + str(i+1) + '.dat', unpack=True)
        if np.sum(p) < 0.005:
            txt_file.write(str(i) + '\n')